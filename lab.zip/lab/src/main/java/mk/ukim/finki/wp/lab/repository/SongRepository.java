package mk.ukim.finki.wp.lab.repository;

import jakarta.servlet.ServletException;
import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class SongRepository {
    private List<Song> songList;

    public SongRepository(List<Song> songList) {
        this.songList = songList;
    }
    public void init() throws ServletException
    {
        this.songList = new ArrayList<>();
        this.songList.add(new Song("1", "Dali da ti prijdam", "male", 1974));
        this.songList.add(new Song("2", "Angels", "male", 1998));
        this.songList.add(new Song("3", "Crno i belo", "female", 2007));
        this.songList.add(new Song("4", "Basketball", "female", 2019));
    }
    public List<Song> findAll(){
        return songList;
    }
    public Song findByTrackId(String trackId){
        return (Song) songList.stream().filter(r->r.getTrackId().equals(trackId));
    }
    public boolean addArtistToSong(Artist artist, Song song)
    {
        return song.getPerformers().add(new Artist(artist.getId(), artist.getFirstName(), artist.getLastName(), artist.getBio()));
    }

    public String findByTrackID(String trackId) {
        return trackId;
    }
}
