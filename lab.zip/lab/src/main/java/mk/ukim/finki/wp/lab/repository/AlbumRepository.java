package mk.ukim.finki.wp.lab.repository;
import java.util.ArrayList;
import java.util.List;
import mk.ukim.finki.wp.lab.model.Album;
public class AlbumRepository {
    private final List<Album> albums;

    public AlbumRepository() {
        this.albums = new ArrayList<>();
        albums.add(new Album("Thriller", "Pop", "1982"));
        albums.add(new Album("Back in Black", "Hard Rock", "1980"));
        albums.add(new Album("The Dark Side of the Moon", "Progressive Rock", "1973"));
        albums.add(new Album("Rumours", "Rock", "1977"));
        albums.add(new Album("Abbey Road", "Rock", "1969"));
    }

    public List<Album> findAll() {
        return new ArrayList<>(albums);
    }
}
