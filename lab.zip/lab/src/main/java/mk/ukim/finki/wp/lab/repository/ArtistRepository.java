package mk.ukim.finki.wp.lab.repository;

import jakarta.servlet.ServletException;
import mk.ukim.finki.wp.lab.model.Artist;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class ArtistRepository {
    private List<Artist> artistList;
    public ArtistRepository(List<Artist> artistList) {
        this.artistList = artistList;
    }
    public void init() throws ServletException
    {
        this.artistList = new ArrayList<>();
        this.artistList.add(new Artist(1L, "Slave", "Dimitrov", "Bio od Slave Dimitrov"));
        this.artistList.add(new Artist(2L, "Robbie", "Williams", "Bio od Robbie Williams"));
        this.artistList.add(new Artist(3L, "Kaliopi", "Bukle", "Bio od Kaliopi Bukle"));
        this.artistList.add(new Artist(4L, "Celine", "Dion", "Bio od Celine Dion"));
        this.artistList.add(new Artist(5L, "Katy", "Perry", "Bio od Katy Perry"));
    }
    public List<Artist> findAll(){
        return artistList;
    }
    public Optional<Artist> findById(Long id){
        return artistList.stream().filter(r->r.getId().equals(id)).findFirst();
    }

    public void findByID(Long id) {
    }
}
