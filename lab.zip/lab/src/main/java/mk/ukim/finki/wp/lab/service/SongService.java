package mk.ukim.finki.wp.lab.service;

import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;

import java.util.List;

public interface SongService {
    List<Song> listSongs();
    boolean addArtistToSong(Artist artist, Song song);
    public String findByTrackId(String trackId);

    void addRating(String songID, int rating);

    ThreadLocal<Object> findByTrackID(String songID);
}
