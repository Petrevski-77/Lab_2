package mk.ukim.finki.wp.lab.service.impl;

import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.repository.ArtistRepository;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ArtistService implements mk.ukim.finki.wp.lab.service.ArtistService {

    private final ArtistRepository artistRepository;

    public ArtistService(ArtistRepository artistRepository) {
        this.artistRepository = artistRepository;
    }

    @Override
    public List<Artist> listArtists() {
        return this.artistRepository.findAll();
    }

    @Override
    public void ArtistfindById(Long id) {
        this.artistRepository.findByID(id);
    }
}
