package mk.ukim.finki.wp.lab.service.impl;

import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;
import mk.ukim.finki.wp.lab.repository.ArtistRepository;
import mk.ukim.finki.wp.lab.repository.SongRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SongService implements mk.ukim.finki.wp.lab.service.SongService {
    private final ArtistRepository artistRepository;
    private final SongRepository songRepository;

    public SongService(ArtistRepository artistRepository, SongRepository songRepository) {
        this.artistRepository = artistRepository;
        this.songRepository = songRepository;
    }

    @Override
    public List<Song> listSongs() {
        return this.songRepository.findAll();
    }

    @Override
    public boolean addArtistToSong(Artist artist, Song song) {
        return this.songRepository.addArtistToSong(artist, song);
    }

    @Override
    public String findByTrackId(String trackId) {
        return this.songRepository.findByTrackID(trackId);
    }

    @Override
    public void addRating(String songID, int rating) {
    }

    @Override
    public ThreadLocal<Object> findByTrackID(String songID) {
        return null;
    }
}
