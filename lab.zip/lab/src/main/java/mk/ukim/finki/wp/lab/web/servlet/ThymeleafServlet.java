package mk.ukim.finki.wp.lab.web.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;
import mk.ukim.finki.wp.lab.service.SongService;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.io.IOException;
import java.util.List;

@Component
@WebServlet(name = "song-details-servlet", urlPatterns = "/songDetails")
public class ThymeleafServlet extends HttpServlet {

    // Dependency Injection
    private final SongService songService;
    private final SpringTemplateEngine springTemplateEngine;

    public ThymeleafServlet(SongService songService, SpringTemplateEngine springTemplateEngine) {
        this.songService = songService;
        this.springTemplateEngine = springTemplateEngine;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        IWebExchange webExchange = JakartaServletWebApplication
                .buildApplication(getServletContext())
                .buildExchange(req, resp);
        WebContext context = new WebContext(webExchange);

        Song song = (Song) req.getSession().getAttribute("songTrackedID");

        if(song != null){

            context.setVariable("songTitle", song.getSongTitle());
            context.setVariable("songGenre", song.getSongGenre());
            context.setVariable("songReleaseYear", song.getSongReleaseYear());
            List<Artist> performers = song.getPerformers();
            context.setVariable("performers", performers);
        }

//        Artist artist = (Artist) req.getSession().getAttribute("artistID");
//        context.setVariable("artist", artist);

        context.setVariable("song", song);

        springTemplateEngine.process("songDetails.html", context, resp.getWriter());
    }
}
