package mk.ukim.finki.wp.lab.service.impl;

import mk.ukim.finki.wp.lab.model.Album;
import mk.ukim.finki.wp.lab.repository.AlbumRepository;

import java.util.List;

public class AlbumService implements mk.ukim.finki.wp.lab.service.AlbumService {

    private final AlbumRepository albumRepository;

    public AlbumService() {
        this.albumRepository = new AlbumRepository();
    }
    @Override
    public List<Album> findAll() {
        return albumRepository.findAll();
    }
}
