package mk.ukim.finki.wp.lab.model;

import lombok.Data;
import java.util.ArrayList;
import java.util.List;

@Data
public class Song {

    private String songTrackID;
    private String songTitle;
    private String songGenre;
    private int songReleaseYear;
    private List<Artist> performers;
    private List<Integer> ratings;
    private double averageRating;
    private Long id;
    private Album album;
    public Song(String songTrackID, String songTitle, String songGenre, int songReleaseYear) {
        this.songTrackID = songTrackID;
        this.songTitle = songTitle;
        this.songGenre = songGenre;
        this.songReleaseYear = songReleaseYear;
        this.performers = new ArrayList<>();
        this.ratings = new ArrayList<>();
        this.id = generateUniqueId();
    }

    private Long generateUniqueId() {
        return System.currentTimeMillis() + (long) (Math.random() * 1000);
    }

    public void addRating(int rating) {
        ratings.add(rating);
        calculateAverageRating();
    }

    private void calculateAverageRating() {
        if (ratings.isEmpty()) {
            averageRating = 0;
        } else {
            int sum = 0;
            for (int rating : ratings) {
                sum += rating;
            }
            averageRating = sum / (double) ratings.size();
        }
    }

    public Object getTrackId() {
        return songTrackID;
    }
}
/*
@Data
public class Song {
    private String trackId;
    private String title;
    private String genre;
    private int releaseYear;
    private List<Artist> performers;

    public String getTrackId() {
        return trackId;
    }

    public void setTrackId(String trackId) {
        this.trackId = trackId;
    }

    public List<Artist> getPerformers() {
        return performers;
    }

    public void setPerformers(List<Artist> performers) {
        this.performers = performers;
    }

    public Song(String trackId, String title, String genre, int releaseYear) {
        this.trackId = trackId;
        this.title = title;
        this.genre = genre;
        this.releaseYear = releaseYear;
    }

    public Object getSongTitle() {
        return title;
    }

    public Object getSongGenre() {
        return genre;
    }

    public Object getSongReleaseYear() {
        return releaseYear;
    }
}
*/