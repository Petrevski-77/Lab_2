package mk.ukim.finki.wp.lab.web.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mk.ukim.finki.wp.lab.model.Song;
import mk.ukim.finki.wp.lab.service.SongService;
import org.springframework.stereotype.Component;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@Component
@WebServlet(name = "song-list-servlet", urlPatterns = "/listSongs")
public class SongListServlet extends HttpServlet {

    // Dependency Injection
    private final SongService songService;
    private final SpringTemplateEngine springTemplateEngine;

    public SongListServlet(SongService songService, SpringTemplateEngine springTemplateEngine) {
        this.songService = songService;
        this.springTemplateEngine = springTemplateEngine;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        IWebExchange webExchange = JakartaServletWebApplication
                .buildApplication(getServletContext())
                .buildExchange(req, resp);
        WebContext context = new WebContext(webExchange);

        List<Song> songs = songService.listSongs();
        String ratingStr = req.getParameter("rating");

        context.setVariable("songs", songs);
        context.setVariable("rating", ratingStr);

        springTemplateEngine.process("listSongs.html", context, resp.getWriter());
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String songID = req.getParameter("songTrackID");
        String ratingStr = req.getParameter("rating-" + songID);

        if (songID == null || songID.isEmpty()) {
            req.setAttribute("errorMessage", "You must select a song !!!");
            doGet(req, resp);
            return;
        }

        if (ratingStr != null && !ratingStr.isEmpty()) {
            try {
                int rating = Integer.parseInt(ratingStr);
                if (rating >= 0 && rating <= 5) {
                    songService.addRating(songID, rating);
                }
            } catch (NumberFormatException e) {
                req.setAttribute("errorMessage", "Invalid rating value.");
                doGet(req, resp);
                return;
            }
        }

        Song song = (Song) songService.findByTrackID(songID).get();

        req.getSession().setAttribute("songTrackID", song);

        resp.sendRedirect("/artist");
    }
}
